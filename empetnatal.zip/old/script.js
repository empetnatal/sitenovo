function enviarContato() {
    const nome = document.getElementById('contactName').value;
    const email = document.getElementById('contactEmail').value;
    const telefone = document.getElementById('contactPhone').value;
    const texto = document.getElementById('contactText').value;

    console.log('Dados de contato enviados:');
    console.log('Nome:', nome);
    console.log('Email:', email);
    console.log('Telefone:', telefone);
    console.log('Texto:', texto);
}
function enviarPet() {
    const nome = document.getElementById('contactName').value;
    const email = document.getElementById('contactEmail').value;
    const telefone = document.getElementById('contactPhone').value;
    const texto = document.getElementById('contactText').value;

    console.log('Dados de Pet enviados:');
    console.log('Nome:', nome);
    console.log('Email:', email);
    console.log('Telefone:', telefone);
    console.log('Texto:', texto);
}

function enviarPatrocinio() {
    const nome = document.getElementById('contactName').value;
    const email = document.getElementById('contactEmail').value;
    const telefone = document.getElementById('contactPhone').value;
    const texto = document.getElementById('contactText').value;

    console.log('Dados de Patrocinio enviados:');
    console.log('Nome:', nome);
    console.log('Email:', email);
    console.log('Telefone:', telefone);
    console.log('Texto:', texto);
}

function limparCampos() {
    document.getElementById('petName').value = '';
    document.getElementById('petBreed').value = '';
    document.getElementById('petAge').value = '';
    document.getElementById('petDescription').value = '';
    document.getElementById('petType').selectedIndex = 0;
    document.getElementById('contactName').value = '';
    document.getElementById('contactEmail').value = '';
    document.getElementById('contactPhone').value = '';
    document.getElementById('contactText').value = '';
}
